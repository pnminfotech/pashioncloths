<footer class="  full-row bg-footer footer-simple-dark text-white">
            <div class="container">

                <div class="row">
                    <!-- <div class="row row-cols-lg-4 row-cols-md-4 row-cols-1 mt-1 "> -->
                  
                        <div class="col-md-4 ">
                            <div class="">

                                <img class="img-fluid center" src="assets/images/logo/pationlogo.png"
                                    alt="Image not found !" style="width:50%;">
                                <br>
                                <p>Pashion Clothing Pvt. ltd is a custom apparel manufacturer and decorator company. We are
                                    a trusted partner in providing modern apparel design solutions for the corporate world.
                                </p>
                                <a href=""><img src="assets/images/logo/linkedin.png" alt="" style="width: 9%; "></a> &nbsp;
                                <a href=""><img src="assets/images/logo/facebook.png" alt="" style="width:9%;"></a>
                            </div>

                        </div>



                  

                    <div class=" col-md-2 footer-widget rmt-4">
                     

                        <h5 class="text-white  down-line">Our Products</h5>
                  
                        <ul class="list-unstyled text-small" style="line-height: 1.9">

                            <li class="flaticon-next flat-mini text-white"> Aprons</li>
                            <li class="flaticon-next flat-mini text-white"> T-shirts</li>
                            <li class="flaticon-next flat-mini text-white"> Suits</li>
                            <li class="flaticon-next flat-mini text-white"> Trousers</li>
                            <li class="flaticon-next flat-mini text-white"> Shirts</li>
                            <li class="flaticon-next flat-mini text-white"> Industrial Uniforms</li>
                            <li class="flaticon-next flat-mini text-white"> Caps</li>
                            <li class="flaticon-next flat-mini text-white"> Sweat-shirts</li>

                        </ul>
                       
                    </div>

                    
                    <div class=" col-md-2 rmt-4">

                        <div class="footer-widget ">
                            <h5 class="text-white down-line">Quick Links</h5>
                   

                            <ul class="list-unstyled text-small ">
                                <li><a class="text-white flaticon-next flat-mini " href="index.php" active> Home</a>
                                </li>
                                <li><a class="text-white flaticon-next flat-mini " href="about.php"> About Us</a>
                                </li>
                                <li><a class="text-white flaticon-next flat-mini" href="Products.php"> Products</a>
                                </li>
                                <li><a class="text-white flaticon-next flat-mini" href="Brands.php"> Associated
                                        Brands</a></li>
                                <li><a class="text-white flaticon-next flat-mini" href="Client.php"> Clients</a>
                                </li>

                                <li><a class="text-white flaticon-next flat-mini"
                                        href="Contact-form.php"> Contact</a></li>
                            </ul>
                        </div>
                    </div>

                    <div class=" col-md-4 rmt-4">
                        <h5 class="text-white down-line">Contact Us</h5>
                        
                        <ul class="list-unstyled text-small">
                            <P class="flaticon-telephone text-white">&nbsp;&nbsp; +91-8605014422 /
                                +91-7774080211</P>

                        </ul>
                     
                        <ul>
                            <P class="flaticon-email text-white">&nbsp;&nbsp; info@pashionclothing.com
                               </P>
                                <P class="flaticon-email text-white">&nbsp;&nbsp; 
                                  aiyaz@pashionclothing.com</P>
                        </ul>
                     
                        <ul>
                            <P class="flaticon-placeholder text-white">&nbsp;&nbsp; Pashion Clothing Pvt Ltd 1st
                                floor, Rashmi Industrial Estate,
                                S.no.70/A1/2/2A, Lane, 2, Salunke Vihar Rd, Wanwadi, Pune, 411040.</P>
                        </ul>
                    </div>

                

                </div>
            </div>

        </footer>
    <!-- Footer Section End -->

    <!-- Copyright Section Start -->
    <div class="copyright bg-dark py-4">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <span>© 2024 All Rights Reserved. Pashionclothing</span>
                    <span class="pl-3">Design By <span class="text-primary"><a href="https://pnminfotech.com/">PNM
                                Infotech</a></span></span>
                </div>
                
            </div>
        </div>
    </div>