<header class="nav-split-simple nav-on-top fixed-bg-white ">
            <div class="top-header sm-mx-none shadow-sm bg-dark position-relative ">
                <div class="container">
                    <div class="row">

                        <div class="col-lg-6">
                            <div class=" top-profile left  mt-2">
                                <ul class="d-flex justify-content-start">


                                    <div class="navbar-nav  position-relative">

                                        <p class="flaticon-email text-white">&nbsp;&nbsp; info@pashionclothing.com
                                            /aiyaz@pashionclothing.com</p>

                                    </div>

                                </ul>


                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="top-profile Right mt-2">
                                <ul class="d-flex justify-content-end">
                                    <div class="navbar-nav cart-view position-relative">

                                        <p class="flaticon-telephone text-white">&nbsp;&nbsp; +91-8605014422 /
                                            +91-7774080211</p>

                                    </div>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="main-nav py-lg-4">
                <div class="container">
                    <div class="row">
                        <div class="col">
                            <nav class="navbar navbar-expand-lg nav-line-active nav-dark nav-primary-hover">
                                <a class="navbar-brand center" href="index.php"><img class="nav-logo center"
                                        src="assets/images/logo/pationlogo.png" alt="Image not found !"></a>
                                <button class="navbar-toggler" type="button" data-toggle="collapse"
                                    data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                                    aria-expanded="false" aria-label="Toggle navigation">
                                    <span class="navbar-toggler-icon flaticon-menu flat-small text-primary"></span>
                                </button>
                                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                                    <ul class="navbar-nav w-100">
                                        <li class="nav-item ">

                                            <a class="nav-link text-center" href="index.php">Home</a>

                                        </li>
                                        <li class="nav-item"><a class="nav-link text-center" href="about.php">About
                                                Us</a>

                                        </li>

                                        <li class="nav-item "><a class="nav-link text-center"
                                                href="Our-Product.php">Products</a>

                                        </li>
                                        <li></li>

                                        <li class="nav-item ">
                                            <a class="nav-link text-center" href="Brands.php">Associated
                                                Brands</a>

                                        </li>
                                        <li class="nav-item ">
                                            <a class="nav-link text-center" href="Client.php">Clients</a>

                                        </li>
                                        <li class="nav-item "><a class="nav-link text-center"
                                                href="Contact-form.php">Contact</a></li>
                                    </ul>
                                </div>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </header>